public class Node{
    int value;
    Node left, right;
    Node()
    {
        left= right= null;
    }
    Node(int k)
    {
        value=k;
        left=right=null;
    }
}